#pragma once
// Include all dependencies for easy includes.
#include "matrix/Sparse.h"
#include "reader/Reader.h"
#include "reader/MTXReader.h"
#include "matrix/Utils.h"
#include "analysis/Graph.h"